import 'package:flutter/cupertino.dart';

class AppColor{
  static const Color olive_green= Color(0xFFFF79bd75);
}
